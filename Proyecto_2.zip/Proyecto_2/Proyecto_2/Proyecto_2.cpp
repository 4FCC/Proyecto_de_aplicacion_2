#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <filesystem>

namespace fs = std::filesystem;

// Clase que representa un registro de datos
class RegistroDatos {
public:
    std::string clave;
    std::string datos;

    // Constructor que inicializa la clave y los datos del registro
    RegistroDatos(const std::string& k, const std::string& d) : clave(k), datos(d) {}
};

// Clase que gestiona el almacenamiento y manipulación de datos
class AlmacenamientoDatos {
private:
    std::vector<RegistroDatos> registrosDatos; // Vector para almacenar los registros de datos

    // Función que realiza el hash de una clave para identificar un registro
    std::string Hash(const std::string& clave) {
        // Asegúrarse de que el hash siempre tenga 10 caracteres de longitud
        std::string hash = clave;
        hash.resize(10, ' ');
        return hash;
    }

public:
    // Función para cargar datos desde un archivo de texto y ordenarlos
    void CargarDatosDesdeArchivo(const std::string& nombreArchivo) {
        if (!fs::exists(nombreArchivo)) {
            std::cerr << "Error: El archivo no existe." << std::endl;
            return;
        }

        std::ifstream archivo(nombreArchivo);
        if (!archivo.is_open()) {
            std::cerr << "Error: No se puede abrir el archivo." << std::endl;
            return;
        }

        registrosDatos.clear(); // Limpiar registros anteriores

        std::string linea;
        while (std::getline(archivo, linea)) {
            std::string clave = linea.substr(0, 10);
            std::string datos = linea.substr(11);
            registrosDatos.push_back(RegistroDatos(clave, datos));
        }

        archivo.close();

        // Ordenar los registros por clave utilizando una función lambda
        std::sort(registrosDatos.begin(), registrosDatos.end(), [](const RegistroDatos& a, const RegistroDatos& b) {
            return a.clave < b.clave;
            });

        std::cout << "Datos cargados y ordenados exitosamente." << std::endl;
    }

    // Función para buscar registros por prefijo de clave utilizando búsqueda secuencial
    void BuscarPorPrefijoClave(const std::string& prefijo) {
        std::vector<RegistroDatos> resultados;

        for (const RegistroDatos& registro : registrosDatos) {
            if (registro.clave.find(prefijo) == 0) {
                resultados.push_back(registro);
            }
        }

        if (resultados.empty()) {
            std::cout << "No se encontraron registros con el prefijo de clave especificado." << std::endl;
        }
        else {
            std::cout << "Registros con el prefijo de clave especificado:" << std::endl;
            for (const RegistroDatos& registro : resultados) {
                std::cout << registro.clave << ", " << registro.datos << std::endl;
            }
        }
    }

    // Función para buscar registros por valor utilizando búsqueda secuencial
    void BuscarPorValor(const std::string& valor) {
        std::vector<RegistroDatos> resultados;
        for (const RegistroDatos& registro : registrosDatos) {
            if (registro.datos.find(valor) != std::string::npos) {
                resultados.push_back(registro);
            }
        }

        if (resultados.empty()) {
            std::cout << "No se encontraron registros con el valor especificado." << std::endl;
        }
        else {
            std::cout << "Registros con el valor especificado:" << std::endl;
            for (const RegistroDatos& registro : resultados) {
                std::cout << registro.clave << ", " << registro.datos << std::endl;
            }
        }
    }
};

// Función principal del programa
int main() {
    AlmacenamientoDatos almacenamientoDatos;
    std::string nombreArchivo;
    std::string prefijo;
    std::string valor;

    while (true) {
        int opcion;
        std::cout << "Opciones:\n1. Cargar datos desde un archivo de texto\n2. Buscar por prefijo de clave\n3. Buscar por valor\n4. Salir\n";
        std::cin >> opcion;

        switch (opcion) {
        case 1:
            std::cin.ignore();  // Limpia el búfer de entrada
            std::cout << "Ingresa la ruta al archivo de texto: ";
            std::getline(std::cin, nombreArchivo);
            almacenamientoDatos.CargarDatosDesdeArchivo(nombreArchivo);
            break;

        case 2:
            std::cout << "Ingresa el prefijo de clave a buscar: ";
            std::cin >> prefijo;
            almacenamientoDatos.BuscarPorPrefijoClave(prefijo);
            break;

        case 3:
            std::cin.ignore(); // Limpia el búfer de entrada
            std::cout << "Ingresa el valor a buscar: ";
            std::getline(std::cin, valor);
            almacenamientoDatos.BuscarPorValor(valor);
            break;

        case 4:
            std::cout << "Adiós. Gracias por usar el programa." << std::endl;
            return 0;

        default:
            std::cout << "Opción no válida. Por favor, elige una opción válida." << std::endl;
            break;
        }
    }

    return 0;
}
